# ReClient — Minecraft 1.21.1 (Fabric)

ReClient is a client-side Fabric mod with a configurable HUD and a Right Shift settings menu. This source archive is prepared for Minecraft **1.21.1** and **Java 21**.

## Features
- Right Shift menu with Modules, Performance, and Theme tabs.
- HUD modules: FPS, CPS, ping, coordinates, direction, clock, memory, keystrokes, and armor.
- Zoom, fullbright, toggle sprint, HUD editor, theme customization, and saved settings.
- Crosshair Indicator with configurable size and gap.
- Experimental/preparatory module controls for Motion Blur, No Overlays, and Crystal Optimizer.

## Feature status (important)
- **Crosshair Indicator:** custom crosshair arms are drawn while enabled. The vanilla crosshair may still be visible underneath; replacing it completely is not implemented yet.
- **Motion Blur:** the menu option is a placeholder. A real motion-blur shader is not implemented.
- **No Overlays:** the menu options are placeholders; fire, shield, and totem rendering are not suppressed yet.
- **Crystal Optimizer:** the menu option and particle setting are placeholders; crystal rendering/particle behavior is not changed yet.

These are visual/client-side features only. Do not assume placeholder toggles affect the game until their rendering hooks are implemented and tested.

## Credits
- **4Repeat** — credit requested by the project owner.
- **Project repository:** https://github.com/farazajaz07-beep/ReClient-Real-Download-
- The YouTube channel URL was not supplied, so no channel link is guessed. Add it here when available.

Please retain this credit section when redistributing modified source.

## Build
Use **Java 21**. Java 25 can cause class-file / mixin compatibility problems with this Minecraft toolchain.

```bash
chmod +x gradlew
./gradlew build
```

If the build succeeds, the installable JAR should be in `build/libs/`. Install the normal JAR, not the `-sources.jar`.

## Install on Zalith Launcher
1. Use a Minecraft **1.21.1 Fabric** instance with Java 21.
2. Build the project in a network-enabled Codespace or computer.
3. Copy the normal JAR from `build/libs/` into that instance's `mods` folder.
4. Ensure Fabric Loader and Fabric API are installed for Minecraft 1.21.1.
5. Enter a world and press **Right Shift** to open the menu.

## Build verification
This archive has not been successfully compiled in the current environment: the Gradle distribution download failed because network DNS was unavailable. Run the build in a network-enabled environment and share the complete error output if it fails.


## Crosshair Indicator (1.0.2)

The crosshair is white by default and changes to a pink/red accent when the view ray is targeting another live player within the mod's conservative 3.1-block reach check. It is based on the targeted hitbox, not on whether the attack cooldown is fully charged. The server remains authoritative, so reach, latency, and server-specific combat rules can affect whether a swing actually lands.

This implementation is inspired by the behavior described on the [Crosshair Indicator Modrinth page](https://modrinth.com/mod/crosshair-indicator); it is a ReClient implementation, not a bundled copy of that mod.

Credits: **4Repeat**.
