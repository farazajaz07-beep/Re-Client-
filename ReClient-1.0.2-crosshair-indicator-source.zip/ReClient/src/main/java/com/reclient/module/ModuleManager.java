package com.reclient.module;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

import com.reclient.Stats;
import com.reclient.setting.BoolSetting;
import com.reclient.setting.SliderSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.Direction;
import net.minecraft.client.gui.GuiGraphics;

public final class ModuleManager {
	public static final List<Module> MODULES = new ArrayList<>();
	private static final List<HudModule> HUD = new ArrayList<>();
	public static ZoomModule zoom;

	private ModuleManager() {}

	public static List<HudModule> hud() {
		return Collections.unmodifiableList(HUD);
	}

	private static void add(Module m, boolean enabledByDefault) {
		m.enabled = enabledByDefault;
		MODULES.add(m);
		if (m instanceof HudModule h) HUD.add(h);
	}

	public static void init() {
		if (!MODULES.isEmpty()) return;

		add(new TextHudModule("FPS", "Shows your current frames per second.", 6, 6) {
			@Override protected String label() { return "FPS"; }
			@Override protected String value(Minecraft mc) { return Integer.toString(Stats.fps()); }
		}, true);

		add(new TextHudModule("CPS", "Left and right clicks per second.", 6, 24) {
			@Override protected String label() { return "CPS"; }
			@Override protected String value(Minecraft mc) { return Stats.cpsLeft() + " | " + Stats.cpsRight(); }
		}, true);

		add(new TextHudModule("Ping", "Your latency to the server.", 6, 42) {
			@Override protected String label() { return "Ping"; }
			@Override protected String value(Minecraft mc) {
				LocalPlayer p = mc.player;
				ClientPacketListener conn = mc.getConnection();
				if (p == null || conn == null) return "-";
				PlayerInfo info = conn.getPlayerInfo(p.getUUID());
				return info == null ? "-" : info.getLatency() + " ms";
			}
		}, true);

		add(new TextHudModule("Coordinates", "Your XYZ position.", 6, 60) {
			final SliderSetting decimals = slider("Decimals", 1, 0, 3, 1);
			@Override protected String label() { return "XYZ"; }
			@Override protected String value(Minecraft mc) {
				LocalPlayer p = mc.player;
				if (p == null) return "-";
				String f = "%." + decimals.asInt() + "f";
				return String.format(Locale.ROOT, f + "  " + f + "  " + f, p.getX(), p.getY(), p.getZ());
			}
		}, true);

		add(new TextHudModule("Direction", "Which way you are facing.", 6, 78) {
			@Override protected String label() { return "Facing"; }
			@Override protected String value(Minecraft mc) {
				LocalPlayer p = mc.player;
				if (p == null) return "-";
				Direction d = p.getDirection();
				String n = d.getName();
				String sign = d.getAxisDirection() == Direction.AxisDirection.POSITIVE ? "+" : "-";
				return Character.toUpperCase(n.charAt(0)) + n.substring(1) + " (" + sign + d.getAxis().getName().toUpperCase(Locale.ROOT) + ")";
			}
		}, false);

		add(new TextHudModule("Clock", "Your computer's local time.", 6, 96) {
			final BoolSetting h24 = bool("24 Hour", true);
			final BoolSetting seconds = bool("Show Seconds", false);
			@Override protected String label() { return "Time"; }
			@Override protected String value(Minecraft mc) {
				String pattern = (h24.value ? "HH:mm" : "hh:mm") + (seconds.value ? ":ss" : "") + (h24.value ? "" : " a");
				return LocalTime.now().format(DateTimeFormatter.ofPattern(pattern, Locale.ENGLISH));
			}
		}, false);

		add(new TextHudModule("Memory", "Java memory in use.", 6, 114) {
			@Override protected String label() { return "Mem"; }
			@Override protected String value(Minecraft mc) {
				Runtime r = Runtime.getRuntime();
				long used = (r.totalMemory() - r.freeMemory()) >> 20;
				long max = r.maxMemory() >> 20;
				return used + " / " + max + " MB";
			}
		}, false);

		add(new KeystrokesModule(6, 140), true);
		add(new ArmorModule(9999, 6), true); // clamped to the right edge on first render

		add(new ToggleSprintModule(), false);
		zoom = new ZoomModule();
		add(zoom, true);
		add(new FullbrightModule(), false);

		add(new VisualModule(VisualModule.Kind.CROSSHAIR), true);
		add(new VisualModule(VisualModule.Kind.MOTION_BLUR), false);
		add(new VisualModule(VisualModule.Kind.NO_OVERLAYS), false);
		add(new VisualModule(VisualModule.Kind.CRYSTAL_OPTIMIZER), false);
	}

	public static void tick(Minecraft mc) {
		if (mc.player == null) return;
		for (Module m : MODULES) {
			if (m.enabled) m.tick(mc);
		}
	}

	public static void frame(Minecraft mc) {
		Stats.frame(mc);
		float dt = Stats.dt();
		for (Module m : MODULES) m.frame(mc, dt);
	}

	public static void renderHud(GuiGraphics g) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.options.hideGui || mc.player == null) return;
		if (mc.screen instanceof com.reclient.ui.HudEditorScreen) return;
		for (HudModule h : HUD) {
			if (h.enabled) h.render(g, mc, false);
		}
		for (Module m : MODULES) {
			if (m instanceof VisualModule v) v.render(g, mc);
		}
	}
}
