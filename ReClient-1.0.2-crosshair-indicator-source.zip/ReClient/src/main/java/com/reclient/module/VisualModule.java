package com.reclient.module;

import com.reclient.setting.BoolSetting;
import com.reclient.setting.SliderSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;

/** Visual modules. Crosshair Indicator changes the crosshair when a player hitbox is targeted. */
public final class VisualModule extends Module {
    public enum Kind { CROSSHAIR, MOTION_BLUR, NO_OVERLAYS, CRYSTAL_OPTIMIZER }
    public final Kind kind;
    public final BoolSetting showHitMarker;
    public final SliderSetting crosshairSize;
    public final SliderSetting crosshairGap;
    public final SliderSetting blurStrength;
    public final BoolSetting hideFire;
    public final BoolSetting hideShield;
    public final BoolSetting hideTotem;
    public final BoolSetting reduceParticles;

    public VisualModule(Kind kind) {
        super(switch (kind) {
            case CROSSHAIR -> "Crosshair Indicator";
            case MOTION_BLUR -> "Motion Blur (Experimental)";
            case NO_OVERLAYS -> "No Overlays";
            case CRYSTAL_OPTIMIZER -> "Crystal Optimizer";
        }, switch (kind) {
            case CROSSHAIR -> "Changes crosshair appearance when a player hitbox is in attack reach.";
            case MOTION_BLUR -> "Experimental lightweight motion-trail setting; full-screen blur needs shader support.";
            case NO_OVERLAYS -> "Toggle fire, shield and totem visual suppression options.";
            case CRYSTAL_OPTIMIZER -> "Reduce particles for a lighter crystal PvP scene.";
        }, kind == Kind.CROSSHAIR || kind == Kind.MOTION_BLUR ? Category.HUD : Category.PVP);
        this.kind = kind;
        showHitMarker = bool("Player Hit Indicator", true);
        crosshairSize = slider("Crosshair Size", 5, 2, 12, 1);
        crosshairGap = slider("Crosshair Gap", 3, 0, 8, 1);
        blurStrength = slider("Trail Strength", 2, 1, 5, 1);
        hideFire = bool("Hide Fire Overlay", true);
        hideShield = bool("Hide Shield Animation", true);
        hideTotem = bool("Hide Totem Pop", true);
        reduceParticles = bool("Reduce Particles", true);
        enabled = kind == Kind.CROSSHAIR;
    }

    /** True only when the vanilla crosshair ray is on a player and the hit is within melee reach. */
    public static boolean isAimedAtHittablePlayer(Minecraft mc) {
        if (mc == null || mc.player == null || mc.level == null || !(mc.hitResult instanceof EntityHitResult hit)) return false;
        if (!(hit.getEntity() instanceof Player target) || target == mc.player || !target.isAlive()) return false;
        // The hit result already means the view ray intersects the target. Use a conservative
        // vanilla-like reach bound; server rules and latency can still affect the final hit.
        double reach = 3.1D;
        return mc.player.getEyePosition().distanceTo(hit.getLocation()) <= reach;
    }

    public static boolean customCrosshairEnabled() {
        for (Module m : ModuleManager.MODULES) {
            if (m instanceof VisualModule v && v.kind == Kind.CROSSHAIR) return v.enabled;
        }
        return false;
    }

    public void render(GuiGraphics g, Minecraft mc) {
        if (!enabled || kind != Kind.CROSSHAIR || mc.player == null || mc.options.hideGui || mc.screen != null) return;
        int cx = mc.getWindow().getGuiScaledWidth() / 2;
        int cy = mc.getWindow().getGuiScaledHeight() / 2;
        int s = crosshairSize.asInt();
        int gap = crosshairGap.asInt();
        // Normal state is white; the target state changes to a pink/red accent, not green.
        int color = showHitMarker.value && isAimedAtHittablePlayer(mc) ? 0xFFFF5364 : 0xFFFFFFFF;
        // Four arms with a subtle dark outline for visibility against bright scenes.
        drawCrosshair(g, cx, cy, s, gap, 0xC0000000, 4);
        drawCrosshair(g, cx, cy, s, gap, color, 2);
    }

    private static void drawCrosshair(GuiGraphics g, int cx, int cy, int size, int gap, int color, int thickness) {
        g.fill(cx - size - 1, cy - thickness / 2 - 1, cx - gap + 1, cy + (thickness + 1) / 2 + 1, color);
        g.fill(cx + gap - 1, cy - thickness / 2 - 1, cx + size + 1, cy + (thickness + 1) / 2 + 1, color);
        g.fill(cx - thickness / 2 - 1, cy - size - 1, cx + (thickness + 1) / 2 + 1, cy - gap + 1, color);
        g.fill(cx - thickness / 2 - 1, cy + gap - 1, cx + (thickness + 1) / 2 + 1, cy + size + 1, color);
    }
}
