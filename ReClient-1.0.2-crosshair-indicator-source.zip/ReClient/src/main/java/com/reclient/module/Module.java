package com.reclient.module;

import java.util.ArrayList;
import java.util.List;

import com.reclient.setting.BoolSetting;
import com.reclient.setting.Setting;
import com.reclient.setting.SliderSetting;
import net.minecraft.client.Minecraft;

public abstract class Module {
	public enum Category {
		HUD("HUD"), PVP("PvP"), UTILITY("Utility");

		public final String label;

		Category(String label) {
			this.label = label;
		}
	}

	public final String name;
	public final String description;
	public final Category category;
	public boolean enabled;
	public final List<Setting> settings = new ArrayList<>();

	protected Module(String name, String description, Category category) {
		this.name = name;
		this.description = description;
		this.category = category;
	}

	public void toggle() {
		setEnabled(!enabled);
	}

	public void setEnabled(boolean value) {
		if (value == enabled) return;
		enabled = value;
		if (value) onEnable(); else onDisable();
	}

	public void onEnable() {}

	public void onDisable() {}

	/** Called every client tick while enabled and in a world. */
	public void tick(Minecraft mc) {}

	/** Called every rendered frame (even when disabled, so modules can clean up). */
	public void frame(Minecraft mc, float dt) {}

	protected BoolSetting bool(String name, boolean def) {
		BoolSetting s = new BoolSetting(name, def);
		settings.add(s);
		return s;
	}

	protected SliderSetting slider(String name, double def, double min, double max, double step) {
		SliderSetting s = new SliderSetting(name, def, min, max, step);
		settings.add(s);
		return s;
	}
}
