package com.reclient.module;

import com.reclient.ReClient;
import com.reclient.setting.SliderSetting;
import net.minecraft.client.Minecraft;

/** Hold the zoom key to smoothly zoom in. Uses the FOV option, so no mixins needed. */
public class ZoomModule extends Module {
	public final SliderSetting zoomFov = slider("Zoom FOV", 30, 30, 90, 1);
	public final SliderSetting sensitivity = slider("Sensitivity %", 50, 10, 100, 5);

	private boolean zooming;
	private int savedFov;
	private double savedSens;
	private double cur;

	public ZoomModule() {
		super("Zoom", "Hold C (rebindable) to zoom in smoothly.", Category.UTILITY);
	}

	@Override
	public void frame(Minecraft mc, float dt) {
		if (mc.player == null) {
			zooming = false;
			return;
		}
		boolean want = enabled && ReClient.zoomKey != null && ReClient.zoomKey.isDown() && mc.screen == null;
		double k = 1 - Math.exp(-dt * 16);
		if (want) {
			if (!zooming) {
				zooming = true;
				savedFov = mc.options.fov().get();
				savedSens = mc.options.sensitivity().get();
				cur = savedFov;
			}
			cur += (zoomFov.value - cur) * k;
			mc.options.fov().set((int) Math.round(cur));
			mc.options.sensitivity().set(savedSens * sensitivity.value / 100.0);
		} else if (zooming) {
			mc.options.sensitivity().set(savedSens);
			cur += (savedFov - cur) * k;
			if (Math.abs(savedFov - cur) < 1.0) {
				restore(mc);
			} else {
				mc.options.fov().set((int) Math.round(cur));
			}
		}
	}

	@Override
	public void onDisable() {
		restore(Minecraft.getInstance());
	}

	/** Put FOV and sensitivity back exactly as they were. Safe to call any time. */
	public void restore(Minecraft mc) {
		if (!zooming) return;
		zooming = false;
		mc.options.fov().set(savedFov);
		mc.options.sensitivity().set(savedSens);
	}
}
