package com.reclient.mixin;

import com.reclient.module.VisualModule;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Gui.class)
public abstract class GuiMixin {
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void reclient$replaceVanillaCrosshair(GuiGraphics graphics, CallbackInfo ci) {
        if (VisualModule.customCrosshairEnabled()) ci.cancel();
    }
}
