package com.reclient.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.DoubleConsumer;

import com.reclient.Performance;
import com.reclient.ReClient;
import com.reclient.ReConfig;
import com.reclient.Theme;
import com.reclient.module.Module;
import com.reclient.module.ModuleManager;
import com.reclient.setting.BoolSetting;
import com.reclient.setting.Setting;
import com.reclient.setting.SliderSetting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

/** The Right Shift menu: Modules, Performance and Theme tabs with smooth animations. */
public class ReScreen extends Screen {
	private enum Tab {
		MODULES("Modules"), PERFORMANCE("Performance"), THEME("Theme");

		final String title;

		Tab(String title) {
			this.title = title;
		}
	}

	private static final int PANEL = 0xF2111318;
	private static final int SIDEBAR = 0xFF0C0E12;
	private static final int CARD = 0xFF171A21;
	private static final int CARD_HOVER = 0xFF1D212A;
	private static final int TEXT = 0xFFE8EAF0;
	private static final int MUTED = 0xFF868C9C;
	private static final int TRACK = 0xFF2B303B;
	private static final int R = 6;

	private static final class Hit {
		final int x, y, w, h, clip0, clip1;
		final Runnable click, right;
		final DoubleConsumer drag;

		Hit(int x, int y, int w, int h, int clip0, int clip1, Runnable click, Runnable right, DoubleConsumer drag) {
			this.x = x;
			this.y = y;
			this.w = w;
			this.h = h;
			this.clip0 = clip0;
			this.clip1 = clip1;
			this.click = click;
			this.right = right;
			this.drag = drag;
		}

		boolean contains(double mx, double my) {
			return mx >= x && mx < x + w && my >= y && my < y + h && my >= clip0 && my < clip1;
		}
	}

	private Tab tab = Tab.MODULES;
	private final Map<Object, Float> anims = new HashMap<>();
	private final List<Hit> hits = new ArrayList<>();
	private final Set<Module> expanded = new HashSet<>();
	private Hit dragging;

	private float open, scrollCur, scrollTarget, contentH, dt = 0.016f, scale = 1f, alphaMul = 1f;
	private long lastNs = System.nanoTime();
	private double lmx, lmy;
	private int clip0, clip1;
	private int px, py, pw, ph;
	private String status = "";
	private long statusUntil;

	public ReScreen() {
		super(Component.literal("ReClient"));
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
		// custom background drawn in render()
	}

	// ------------------------------------------------------------------ helpers

	private int A(int color) {
		return UI.alpha(color, alphaMul);
	}

	private float anim(Object key, float target, float speed) {
		float cur = anims.getOrDefault(key, target);
		cur += (target - cur) * Math.min(1f, dt * speed);
		anims.put(key, cur);
		return cur;
	}

	private void txt(GuiGraphics g, String s, float x, float y, float sc, int color) {
		if ((color >>> 24) < 8) return;
		g.pose().pushPose();
		g.pose().translate(x, y, 0f);
		g.pose().scale(sc, sc, 1f);
		g.drawString(font, s, 0, 0, color, false);
		g.pose().popPose();
	}

	private void txtSeq(GuiGraphics g, FormattedCharSequence s, float x, float y, float sc, int color) {
		if ((color >>> 24) < 8) return;
		g.pose().pushPose();
		g.pose().translate(x, y, 0f);
		g.pose().scale(sc, sc, 1f);
		g.drawString(font, s, 0, 0, color, false);
		g.pose().popPose();
	}

	/** Wrapped paragraph; returns the y just below it. */
	private int paragraph(GuiGraphics g, String s, int x, int y, int w, float sc, int color) {
		List<FormattedCharSequence> lines = font.split(Component.literal(s), (int) (w / sc));
		for (FormattedCharSequence line : lines) {
			txtSeq(g, line, x, y, sc, color);
			y += (int) (10 * sc) + 1;
		}
		return y;
	}

	private boolean hit(int x, int y, int w, int h, Runnable click) {
		return hit(x, y, w, h, click, null, null);
	}

	private boolean hit(int x, int y, int w, int h, Runnable click, Runnable right, DoubleConsumer drag) {
		if (y + h <= clip0 || y >= clip1) return false;
		Hit hh = new Hit(x, y, w, h, clip0, clip1, click, right, drag);
		hits.add(hh);
		return hh.contains(lmx, lmy);
	}

	private void save() {
		ReConfig.save();
	}

	private void say(String s) {
		status = s;
		statusUntil = System.currentTimeMillis() + 2500;
	}

	// ------------------------------------------------------------------ widgets

	private void drawSwitch(GuiGraphics g, Object key, int x, int y, int w, int h, boolean on) {
		float t = anim(key, on ? 1f : 0f, 16f);
		int bg = UI.lerpColor(TRACK, Theme.accent(), t);
		UI.roundRect(g, x, y, w, h, h / 2, A(bg));
		int kx = x + 2 + Math.round((w - h) * t);
		UI.roundRect(g, kx, y + 2, h - 4, h - 4, (h - 4) / 2, A(0xFFFFFFFF));
	}

	private void switchRow(GuiGraphics g, Object key, String label, int x, int y, int w, boolean on, Runnable toggle, boolean interactive) {
		txt(g, label, x + 4, y + 5, 1f, A(TEXT));
		drawSwitch(g, key, x + w - 30, y + 4, 26, 12, on);
		if (interactive) hit(x, y, w, 20, toggle);
	}

	private void sliderRow(GuiGraphics g, String label, int x, int y, int w, double frac, String valueText, DoubleConsumer setFraction, boolean interactive) {
		txt(g, label, x + 4, y + 5, 1f, A(TEXT));
		int trackW = 96;
		int tx = x + w - 34 - 6 - trackW;
		int ty = y + 8;
		frac = Math.max(0, Math.min(1, frac));
		UI.roundRect(g, tx, ty, trackW, 4, 2, A(TRACK));
		int fw = (int) (trackW * frac);
		UI.roundRect(g, tx, ty, Math.max(4, fw), 4, 2, A(Theme.accent()));
		UI.roundRect(g, tx + fw - 4, ty - 2, 8, 8, 4, A(0xFFFFFFFF));
		txt(g, valueText, x + w - 2 - font.width(valueText), y + 5, 1f, A(MUTED));
		if (interactive) {
			final int ftx = tx;
			DoubleConsumer drag = mx -> setFraction.accept((mx - ftx) / trackW);
			hit(tx - 6, y, trackW + 12, 20, () -> drag.accept(lmx), null, drag);
		}
	}

	private void settingRow(GuiGraphics g, Setting s, int x, int y, int w, boolean interactive) {
		if (s instanceof BoolSetting b) {
			switchRow(g, b, b.name, x, y, w, b.value, () -> {
				b.value = !b.value;
				save();
			}, interactive);
		} else if (s instanceof SliderSetting sl) {
			sliderRow(g, sl.name, x, y, w, sl.fraction(), sl.display(), sl::setFraction, interactive);
		}
	}

	private void button(GuiGraphics g, Object key, String label, int x, int y, int w, int h, boolean enabled, Runnable click) {
		boolean hov = enabled && hit(x, y, w, h, click);
		float t = anim(key, hov ? 1f : 0f, 16f);
		int bg = UI.lerpColor(CARD, UI.alpha(Theme.accent(), 0.45f), t);
		UI.roundRect(g, x, y, w, h, 4, A(bg));
		int col = enabled ? TEXT : 0xFF5A5F6C;
		txt(g, label, x + (w - font.width(label)) / 2f, y + (h - 8) / 2f, 1f, A(col));
	}

	// ------------------------------------------------------------------ main render

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
		long now = System.nanoTime();
		dt = Math.min(0.1f, (now - lastNs) / 1_000_000_000f);
		lastNs = now;
		open += (1f - open) * Math.min(1f, dt * 14f);
		if (open > 0.995f) open = 1f;
		alphaMul = open;
		scale = 0.93f + 0.07f * open;
		hits.clear();

		g.fill(0, 0, width, height, ((int) (150 * open) << 24));

		pw = Math.min(440, width - 24);
		ph = Math.min(280, height - 24);
		px = (width - pw) / 2;
		py = (height - ph) / 2;

		double cx = width / 2.0, cy = height / 2.0;
		lmx = cx + (mouseX - cx) / scale;
		lmy = cy + (mouseY - cy) / scale;

		g.pose().pushPose();
		g.pose().translate(width / 2f, height / 2f, 0f);
		g.pose().scale(scale, scale, 1f);
		g.pose().translate(-width / 2f, -height / 2f, 0f);
		drawPanel(g);
		g.pose().popPose();
	}

	private void drawPanel(GuiGraphics g) {
		clip0 = py;
		clip1 = py + ph;

		UI.roundRect(g, px, py, pw, ph, R, A(PANEL));

		// sidebar
		int sw = 98;
		UI.roundRect(g, px, py, sw, ph, R, A(SIDEBAR));
		g.fill(px + sw - R, py, px + sw, py + ph, A(SIDEBAR));

		g.pose().pushPose();
		g.pose().translate((float) (px + 14), (float) (py + 14), 0f);
		g.pose().scale(1.4f, 1.4f, 1f);
		g.drawString(font, "Re", 0, 0, A(Theme.accent()), false);
		g.drawString(font, "Client", font.width("Re"), 0, A(TEXT), false);
		g.pose().popPose();
		txt(g, "v1.0  smooth ui", px + 14, py + 29, 0.7f, A(MUTED));

		// tabs with a smoothly sliding highlight
		int ty = py + 48;
		Tab[] tabs = Tab.values();
		float hy = anim("tabY", ty + tab.ordinal() * 26, 18f);
		UI.roundRect(g, px + 8, Math.round(hy), sw - 16, 22, 5, A(UI.alpha(Theme.accent(), 0.22f)));
		g.fill(px + 8, Math.round(hy) + 5, px + 10, Math.round(hy) + 17, A(Theme.accent()));
		for (int i = 0; i < tabs.length; i++) {
			Tab t = tabs[i];
			int y = ty + i * 26;
			boolean hov = hit(px + 8, y, sw - 16, 22, () -> {
				tab = t;
				scrollCur = 0;
				scrollTarget = 0;
			});
			float sel = anim("tabSel" + i, tab == t ? 1f : 0f, 14f);
			float hv = anim("tabHov" + i, hov ? 1f : 0f, 14f);
			int col = UI.lerpColor(UI.lerpColor(MUTED, 0xFFC4C8D4, hv), 0xFFFFFFFF, sel);
			txt(g, t.title, px + 18, y + 7, 1f, A(col));
		}

		String keyName = ReClient.menuKey == null ? "Right Shift" : ReClient.menuKey.getTranslatedKeyMessage().getString();
		txt(g, keyName + " to close", px + 14, py + ph - 16, 0.75f, A(MUTED));

		// scrolled content
		int cx0 = px + sw + 14;
		int cy0 = py + 14;
		int cw = pw - sw - 28;
		clip0 = py + 8;
		clip1 = py + ph - 8;
		scrollTarget = Math.max(0, Math.min(scrollTarget, Math.max(0, contentH - (clip1 - clip0))));
		scrollCur += (scrollTarget - scrollCur) * Math.min(1f, dt * 16f);

		g.enableScissor(cx0 - 6, clip0, px + pw - 6, clip1);
		int startY = cy0 - Math.round(scrollCur);
		int endY = switch (tab) {
			case MODULES -> drawModules(g, cx0, startY, cw);
			case PERFORMANCE -> drawPerformance(g, cx0, startY, cw);
			case THEME -> drawTheme(g, cx0, startY, cw);
		};
		g.disableScissor();
		contentH = endY - startY + 12;

		// scrollbar
		int viewH = clip1 - clip0;
		if (contentH > viewH) {
			float frac = viewH / contentH;
			int barH = Math.max(16, (int) (viewH * frac));
			int barY = clip0 + (int) ((viewH - barH) * (scrollCur / (contentH - viewH)));
			UI.roundRect(g, px + pw - 8, barY, 3, barH, 1, A(UI.alpha(Theme.accent(), 0.6f)));
		}
	}

	// ------------------------------------------------------------------ tabs

	private int drawModules(GuiGraphics g, int x, int y0, int w) {
		int y = y0;
		txt(g, "Modules", x, y + 2, 1.4f, A(TEXT));
		button(g, "btnHud", "Edit HUD", x + w - 72, y, 72, 16, true, () -> minecraft.setScreen(new HudEditorScreen(this)));
		y += 28;

		for (Module.Category cat : Module.Category.values()) {
			txt(g, cat.label.toUpperCase(), x + 2, y, 0.8f, A(MUTED));
			y += 13;
			for (Module m : ModuleManager.MODULES) {
				if (m.category != cat) continue;
				y = drawModuleCard(g, m, x, y, w);
			}
			y += 4;
		}
		return y;
	}

	private int drawModuleCard(GuiGraphics g, Module m, int x, int y, int w) {
		boolean exp = expanded.contains(m);
		float ea = anim(m, exp ? 1f : 0f, 14f);
		int setH = m.settings.isEmpty() ? 0 : m.settings.size() * 22 + 6;
		int h = 30 + Math.round(setH * ea);

		Runnable toggleExpand = () -> {
			if (m.settings.isEmpty()) return;
			if (!expanded.remove(m)) expanded.add(m);
		};
		boolean hov = hit(x, y, w, 30, toggleExpand, toggleExpand, null);
		float hv = anim("hov:" + m.name, hov ? 1f : 0f, 16f);
		UI.roundRect(g, x, y, w, h, 5, A(UI.lerpColor(CARD, CARD_HOVER, hv)));

		float on = anim("on:" + m.name, m.enabled ? 1f : 0f, 14f);
		g.fill(x, y + 8, x + 2, y + 22, A(UI.alpha(Theme.accent(), on)));

		txt(g, m.name, x + 12, y + 7, 1f, A(TEXT));
		String desc = font.plainSubstrByWidth(m.description, (int) ((w - 90) / 0.8f));
		txt(g, desc, x + 12, y + 18, 0.8f, A(MUTED));

		if (!m.settings.isEmpty()) {
			for (int i = 0; i < 3; i++) {
				g.fill(x + w - 58 + i * 4, y + 14, x + w - 56 + i * 4, y + 16, A(MUTED));
			}
		}
		drawSwitch(g, "sw:" + m.name, x + w - 40, y + 9, 28, 12, m.enabled);
		hit(x + w - 44, y + 5, 36, 20, () -> {
			m.toggle();
			save();
		});

		if (ea > 0.02f && !m.settings.isEmpty()) {
			float saved = alphaMul;
			alphaMul *= ea;
			for (int i = 0; i < m.settings.size(); i++) {
				settingRow(g, m.settings.get(i), x + 10, y + 33 + i * 22, w - 20, ea > 0.9f);
			}
			alphaMul = saved;
		}
		return y + h + 6;
	}

	private int drawPerformance(GuiGraphics g, int x, int y0, int w) {
		int y = y0;
		txt(g, "Performance", x, y + 2, 1.4f, A(TEXT));
		if (System.currentTimeMillis() < statusUntil) {
			txt(g, status, x + w - font.width(status), y + 5, 1f, A(Theme.accent()));
		}
		y += 24;
		y = paragraph(g, "One-click video presets for more FPS. Your original settings are backed up the first time you apply one.", x, y, w, 0.85f, A(MUTED));
		y += 8;

		int gap = 6;
		int cardW = (w - gap * 2) / 3;
		int cardH = 66;
		for (int i = 0; i < Performance.PRESETS.length; i++) {
			Performance.Preset p = Performance.PRESETS[i];
			int bx = x + i * (cardW + gap);
			boolean active = p.name().equals(Performance.active);
			boolean hov = hit(bx, y, cardW, cardH, () -> {
				Performance.apply(minecraft, p);
				say("Applied " + p.name());
			});
			float hv = anim("pre" + i, hov ? 1f : 0f, 16f);
			if (active) UI.roundRect(g, bx - 1, y - 1, cardW + 2, cardH + 2, 6, A(Theme.accent()));
			UI.roundRect(g, bx, y, cardW, cardH, 5, A(UI.lerpColor(CARD, CARD_HOVER, hv)));
			txt(g, p.name(), bx + 8, y + 8, 1.1f, A(TEXT));
			paragraph(g, p.blurb(), bx + 8, y + 24, cardW - 14, 0.8f, A(MUTED));
		}
		y += cardH + 10;

		button(g, "btnRestore", "Restore my original settings", x, y, w, 22, Performance.hasBackup(), () -> {
			Performance.restore(minecraft);
			say("Original settings restored");
		});
		y += 32;

		txt(g, "CURRENT VIDEO SETTINGS", x + 2, y, 0.8f, A(MUTED));
		y += 14;
		var o = minecraft.options;
		String[][] rows = {
			{"Render distance", o.renderDistance().get() + " chunks"},
			{"Simulation distance", o.simulationDistance().get() + " chunks"},
			{"Graphics", o.graphicsMode().get().name().charAt(0) + o.graphicsMode().get().name().substring(1).toLowerCase()},
			{"VSync", o.enableVsync().get() ? "On" : "Off"},
			{"Max FPS", o.framerateLimit().get() >= 260 ? "Unlimited" : Integer.toString(o.framerateLimit().get())},
		};
		for (String[] r : rows) {
			txt(g, r[0], x + 4, y, 1f, A(TEXT));
			txt(g, r[1], x + w - 2 - font.width(r[1]), y, 1f, A(MUTED));
			y += 14;
		}
		y += 8;
		y = paragraph(g, "Tip: for even bigger gains, put Sodium, Lithium, FerriteCore and EntityCulling in your mods folder next to ReClient. They work together.", x, y, w, 0.85f, A(MUTED));
		return y;
	}

	private int drawTheme(GuiGraphics g, int x, int y0, int w) {
		int y = y0;
		txt(g, "Theme", x, y + 2, 1.4f, A(TEXT));
		y += 28;

		txt(g, "ACCENT COLOR", x + 2, y, 0.8f, A(MUTED));
		y += 13;
		int sw = 20;
		for (int i = 0; i < Theme.PRESETS.length; i++) {
			int sx = x + 2 + i * (sw + 6);
			final int idx = i;
			boolean hov = hit(sx, y, sw, sw, () -> {
				Theme.hue = Theme.PRESETS[idx][0];
				Theme.sat = Theme.PRESETS[idx][1];
				Theme.rainbow = false;
				save();
			});
			boolean selected = !Theme.rainbow && Math.abs(Theme.hue - Theme.PRESETS[i][0]) < 0.005f && Math.abs(Theme.sat - Theme.PRESETS[i][1]) < 0.005f;
			float t = anim("sw" + i, selected ? 1f : hov ? 0.5f : 0f, 16f);
			if (t > 0.02f) UI.roundRect(g, sx - 2, y - 2, sw + 4, sw + 4, 7, A(UI.alpha(0xFFFFFFFF, t)));
			UI.roundRect(g, sx, y, sw, sw, 5, A(Theme.swatch(i)));
		}
		y += sw + 12;

		sliderRow(g, "Hue", x, y, w, Theme.hue, Math.round(Theme.hue * 360) + "°", f -> {
			Theme.hue = (float) f;
			Theme.rainbow = false;
		}, true);
		y += 22;
		sliderRow(g, "Saturation", x, y, w, Theme.sat, Math.round(Theme.sat * 100) + "%", f -> Theme.sat = (float) f, true);
		y += 22;
		sliderRow(g, "HUD opacity", x, y, w, Theme.panelAlpha / 255.0, Math.round(Theme.panelAlpha / 2.55f) + "%", f -> Theme.panelAlpha = (int) Math.round(f * 255), true);
		y += 22;
		sliderRow(g, "Corner radius", x, y, w, Theme.radius / 8.0, Integer.toString(Theme.radius), f -> Theme.radius = (int) Math.round(f * 8), true);
		y += 26;

		switchRow(g, "rainbow", "Rainbow accent", x, y, w, Theme.rainbow, () -> {
			Theme.rainbow = !Theme.rainbow;
			save();
		}, true);
		y += 22;
		switchRow(g, "shadow", "HUD text shadow", x, y, w, Theme.textShadow, () -> {
			Theme.textShadow = !Theme.textShadow;
			save();
		}, true);
		y += 30;

		// live preview
		txt(g, "PREVIEW", x + 2, y, 0.8f, A(MUTED));
		y += 13;
		int pwid = 70, phgt = 20;
		UI.roundRect(g, x + 2, y, pwid, phgt, Theme.radius, A(Theme.panel() | 0xFF000000));
		int r = Math.min(Theme.radius, phgt / 2);
		g.fill(x + 2, y + r, x + 4, y + phgt - r, A(Theme.accent()));
		txt(g, "FPS", x + 10, y + 6, 1f, A(Theme.accent()));
		txt(g, "240", x + 10 + font.width("FPS") + 4, y + 6, 1f, A(0xFFFFFFFF));
		y += phgt;
		return y;
	}

	// ------------------------------------------------------------------ input

	@Override
	public boolean mouseClicked(double mx, double my, int button) {
		if (open < 0.8f) return true;
		for (int i = hits.size() - 1; i >= 0; i--) {
			Hit h = hits.get(i);
			if (!h.contains(lmx, lmy)) continue;
			if (button == 1) {
				if (h.right != null) h.right.run();
			} else if (button == 0) {
				if (h.click != null) h.click.run();
				if (h.drag != null) dragging = h;
			}
			return true;
		}
		return super.mouseClicked(mx, my, button);
	}

	@Override
	public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
		if (dragging != null && button == 0) {
			double cx = width / 2.0;
			dragging.drag.accept(cx + (mx - cx) / scale);
			return true;
		}
		return super.mouseDragged(mx, my, button, dx, dy);
	}

	@Override
	public boolean mouseReleased(double mx, double my, int button) {
		if (dragging != null) {
			dragging = null;
			save();
		}
		return super.mouseReleased(mx, my, button);
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
		scrollTarget = Math.max(0, Math.min(scrollTarget - (float) scrollY * 28f, Math.max(0, contentH - (clip1 - clip0))));
		return true;
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		if (ReClient.menuKey != null && ReClient.menuKey.matches(keyCode, scanCode)) {
			onClose();
			return true;
		}
		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public void onClose() {
		save();
		super.onClose();
	}
}
